(function() {
    const implementors = Object.fromEntries([["mcdx_ql",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/error/trait.Error.html\" title=\"trait core::error::Error\">Error</a> for <a class=\"struct\" href=\"mcdx_ql/struct.Error.html\" title=\"struct mcdx_ql::Error\">Error</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/error/trait.Error.html\" title=\"trait core::error::Error\">Error</a> for <a class=\"struct\" href=\"mcdx_ql/struct.IntervalError.html\" title=\"struct mcdx_ql::IntervalError\">IntervalError</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[529]}