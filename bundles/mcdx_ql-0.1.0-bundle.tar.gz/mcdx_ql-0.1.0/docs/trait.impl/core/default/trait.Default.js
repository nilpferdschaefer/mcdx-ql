(function() {
    const implementors = Object.fromEntries([["mcdx_ql",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/default/trait.Default.html\" title=\"trait core::default::Default\">Default</a> for <a class=\"struct\" href=\"mcdx_ql/struct.Scaffolds.html\" title=\"struct mcdx_ql::Scaffolds\">Scaffolds</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[281]}