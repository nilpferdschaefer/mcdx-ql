(function() {
    const implementors = Object.fromEntries([["mcdx_ql",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/hash/trait.Hash.html\" title=\"trait core::hash::Hash\">Hash</a> for <a class=\"enum\" href=\"mcdx_ql/enum.CallOp.html\" title=\"enum mcdx_ql::CallOp\">CallOp</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[251]}