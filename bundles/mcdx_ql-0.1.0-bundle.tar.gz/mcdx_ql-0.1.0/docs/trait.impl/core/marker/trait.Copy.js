(function() {
    const implementors = Object.fromEntries([["mcdx_ql",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/marker/trait.Copy.html\" title=\"trait core::marker::Copy\">Copy</a> for <a class=\"enum\" href=\"mcdx_ql/enum.BinOp.html\" title=\"enum mcdx_ql::BinOp\">BinOp</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/marker/trait.Copy.html\" title=\"trait core::marker::Copy\">Copy</a> for <a class=\"enum\" href=\"mcdx_ql/enum.CallOp.html\" title=\"enum mcdx_ql::CallOp\">CallOp</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/marker/trait.Copy.html\" title=\"trait core::marker::Copy\">Copy</a> for <a class=\"enum\" href=\"mcdx_ql/enum.ErrorCode.html\" title=\"enum mcdx_ql::ErrorCode\">ErrorCode</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[745]}